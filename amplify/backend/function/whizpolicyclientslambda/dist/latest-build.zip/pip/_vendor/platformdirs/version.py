""" Version information """

__version__ = "2.4.0"
__version_info__ = (2, 4, 0)
